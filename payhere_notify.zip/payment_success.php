<?php
/**
 * PayHere Payment Success Handler
 */
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .success-container {
            background: white;
            padding: 60px 40px;
            border-radius: 20px;
            text-align: center;
            max-width: 500px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .success-icon {
            width: 80px;
            height: 80px;
            background: #10b981;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            font-size: 40px;
        }
        h1 {
            color: #059669;
            margin-bottom: 16px;
            font-size: 32px;
        }
        p {
            color: #666;
            line-height: 1.6;
            margin-bottom: 12px;
        }
        .order-id {
            background: #f0fdf4;
            padding: 16px;
            border-radius: 8px;
            margin: 24px 0;
            font-family: monospace;
        }
        .btn {
            background: #10b981;
            color: white;
            padding: 14px 32px;
            border-radius: 8px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            font-weight: 600;
        }
        .payment-details {
            text-align: left;
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 24px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e0e0e0;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-icon">✓</div>
        <h1>Payment Successful!</h1>
        <p>Thank you for your payment. Your transaction has been completed successfully.</p>
        
        <?php if (isset($_GET['order_id'])): ?>
            <div class="order-id">
                <strong>Order ID:</strong> <?php echo htmlspecialchars($_GET['order_id']); ?>
            </div>
        <?php endif; ?>
        
        <div class="payment-details">
            <h3 style="margin-bottom: 16px;">Payment Details</h3>
            <?php if (isset($_GET['payment_id'])): ?>
                <div class="detail-row">
                    <span>Payment ID:</span>
                    <strong><?php echo htmlspecialchars($_GET['payment_id']); ?></strong>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['payhere_amount'])): ?>
                <div class="detail-row">
                    <span>Amount:</span>
                    <strong>LKR <?php echo htmlspecialchars($_GET['payhere_amount']); ?></strong>
                </div>
            <?php endif; ?>
            
            <div class="detail-row">
                <span>Status:</span>
                <strong style="color: #10b981;">Completed</strong>
            </div>
        </div>
        
        <p style="margin-top: 24px;">A confirmation email has been sent to your registered email address.</p>
        
        <a href="/" class="btn">Return to Home</a>
    </div>
</body>
</html>
