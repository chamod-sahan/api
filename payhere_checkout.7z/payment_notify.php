<?php
/**
 * PayHere Server Notify Handler (IPN)
 * This receives server-to-server notifications from PayHere
 */

// Log file for debugging
$logFile = 'payhere_notify.log';

// Get POST data from PayHere
$merchant_id = $_POST['merchant_id'] ?? '';
$order_id = $_POST['order_id'] ?? '';
$payment_id = $_POST['payment_id'] ?? '';
$payhere_amount = $_POST['payhere_amount'] ?? '';
$payhere_currency = $_POST['payhere_currency'] ?? '';
$status_code = $_POST['status_code'] ?? '';
$md5sig = $_POST['md5sig'] ?? '';

// Your merchant secret (same as in checkout)
$merchant_secret = 'YOUR_MERCHANT_SECRET_HERE'; // REPLACE THIS

// Verify the hash
$local_md5sig = strtoupper(
    md5(
        $merchant_id . 
        $order_id . 
        $payhere_amount . 
        $payhere_currency . 
        $status_code . 
        strtoupper(md5($merchant_secret))
    )
);

// Log the notification
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'merchant_id' => $merchant_id,
    'order_id' => $order_id,
    'payment_id' => $payment_id,
    'amount' => $payhere_amount,
    'currency' => $payhere_currency,
    'status_code' => $status_code,
    'received_hash' => $md5sig,
    'calculated_hash' => $local_md5sig,
    'hash_match' => ($local_md5sig === $md5sig) ? 'YES' : 'NO',
    'all_post_data' => $_POST
];

file_put_contents($logFile, json_encode($logData, JSON_PRETTY_PRINT) . "\n\n", FILE_APPEND);

// Verify hash matches
if ($local_md5sig === $md5sig) {
    // Hash is valid
    
    if ($status_code == 2) {
        // Payment successful
        // TODO: Update your database
        // - Mark order as paid
        // - Send confirmation email
        // - Trigger fulfillment process
        
        file_put_contents($logFile, "SUCCESS: Payment verified for order $order_id\n\n", FILE_APPEND);
        
    } else if ($status_code == 0) {
        // Payment pending
        file_put_contents($logFile, "PENDING: Payment pending for order $order_id\n\n", FILE_APPEND);
        
    } else if ($status_code == -1) {
        // Payment cancelled
        file_put_contents($logFile, "CANCELLED: Payment cancelled for order $order_id\n\n", FILE_APPEND);
        
    } else if ($status_code == -2) {
        // Payment failed
        file_put_contents($logFile, "FAILED: Payment failed for order $order_id\n\n", FILE_APPEND);
        
    } else if ($status_code == -3) {
        // Payment charged back
        file_put_contents($logFile, "CHARGEBACK: Payment charged back for order $order_id\n\n", FILE_APPEND);
    }
    
} else {
    // Hash mismatch - possible tampering
    file_put_contents($logFile, "ERROR: Hash mismatch for order $order_id\n\n", FILE_APPEND);
}

// Always return 200 OK to PayHere
http_response_code(200);
echo "OK";
?>
